Sadly, we are unable to include a copy of the images in the final example from the chapter due to copyright reasons.

Sorry.

